CREATE TABLE public.people
(
    id integer PRIMARY KEY NOT NULL,
    username varchar(128) NOT NULL
);
INSERT INTO public.people (id, username) VALUES (1, 'Matt');